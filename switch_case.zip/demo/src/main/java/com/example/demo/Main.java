package com.example.demo;

public class Main {
    public static void main(String[] args) {
      var estacion = "invierno";

      switch(estacion) {
          case "verano":
              System.out.println("Estamos en verano");
          case "primavera":
              System.out.println("Estamos en primavera");
              break;
          case "otoño":
              System.out.println("Estamos en otoño");
              break;
          case "invierno":
              System.out.println("Estamos en invierno");
              break;
          default:
              System.out.println("No es una estacion");
      }
      }
}



