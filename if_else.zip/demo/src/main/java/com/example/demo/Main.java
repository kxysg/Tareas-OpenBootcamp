package com.example.demo;

public class Main {
    public static void main(String[] args) {
           int numero = 5;

            if (numero > 0) {
                System.out.println("Es positivo");
        } else if (numero < 0) {
            System.out.println("Es negativo");
        } else if (numero == 0) {
            System.out.println("Es cero");
        }
      }
}



