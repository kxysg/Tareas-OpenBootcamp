package com.example.demo;

public class Main {
    public static void main(String[] args) {
            var numero = 0;

            while (numero < 3) {
                System.out.println(numero);
                numero = numero + 1;
            }
      }
}



